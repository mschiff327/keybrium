# Keybrium — Passkey-only auth (SDKs + examples)

Packages:
- `@keybrium/auth` — web/node SDK
- `@keybrium/react` — React helpers
- `@keybrium/react-native` — Expo RN (iOS-first)

Monorepo commands:
- `npm run build` — build all packages
- `npm test` — placeholder tests

Docs: apps/docs (coming soon)

