export const hello = () => "Keybrium auth SDK placeholder";
