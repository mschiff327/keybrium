export const useKeybrium = () => {
  throw new Error("Placeholder hook – implement later");
};
