export const startPasskeyFlow = () => {
  throw new Error("Placeholder RN bridge – implement later");
};
